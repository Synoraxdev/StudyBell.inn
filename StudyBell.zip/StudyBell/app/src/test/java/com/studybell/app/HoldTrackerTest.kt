package com.studybell.app

import com.studybell.app.ui.ringing.HoldTracker
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HoldTrackerTest {
    private var now = 0L
    private fun tracker(durationMs: Long = 3000) = HoldTracker(durationMs) { now }

    @Test fun noProgressUntilPressed() {
        val t = tracker()
        now = 10_000
        assertEquals(0f, t.progress(), 0f)
        assertFalse(t.tryComplete())
    }

    @Test fun progressFollowsRealElapsedTime() {
        val t = tracker()
        now = 1000; t.press()
        now = 2500
        assertEquals(0.5f, t.progress(), 0.001f)
    }

    @Test fun earlyReleaseResetsAndCannotComplete() {
        val t = tracker()
        now = 0; t.press()
        now = 2900; t.release()
        assertEquals(0f, t.progress(), 0f)
        now = 9000
        assertFalse(t.tryComplete())
        assertFalse(t.isFinished)
    }

    @Test fun completesExactlyOnce() {
        val t = tracker()
        now = 0; t.press()
        now = 2999
        assertFalse(t.tryComplete())
        now = 3000
        assertTrue(t.tryComplete())
        assertFalse(t.tryComplete())
        assertEquals(1f, t.progress(), 0f)
    }

    @Test fun secondPressWhileHeldDoesNotRestartOrSpeedUp() {
        val t = tracker()
        now = 0; t.press()
        now = 1000; t.press() // extra finger / duplicate event
        now = 1500
        assertEquals(0.5f, t.progress(), 0.001f)
    }

    @Test fun pressAfterFinishIsIgnored() {
        val t = tracker(1000)
        now = 0; t.press()
        now = 1000; assertTrue(t.tryComplete())
        t.release(); t.press()
        assertFalse(t.tryComplete())
    }

    @Test fun accessibilityActivationCompletesOnce() {
        val t = tracker()
        assertTrue(t.completeForAccessibility())
        assertFalse(t.completeForAccessibility())
    }

    @Test fun oneAndTwoSecondDurations() {
        val one = tracker(1000); now = 0; one.press(); now = 1000
        assertTrue(one.tryComplete())
        val two = tracker(2000); now = 0; two.press(); now = 1999
        assertFalse(two.tryComplete())
    }
}
