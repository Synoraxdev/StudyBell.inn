package com.studybell.app

import com.studybell.app.core.time.TimeFormat
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.DayOfWeek
import java.time.Duration
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Locale

class TimeFormatTest {
    private val us = Locale.US

    @Test fun twelveHourParts() {
        assertEquals("7:05" to "PM", TimeFormat.timeParts(19, 5, false, us))
        assertEquals("12:00" to "AM", TimeFormat.timeParts(0, 0, false, us))
    }

    @Test fun twentyFourHourParts() {
        assertEquals("19:05" to "", TimeFormat.timeParts(19, 5, true, us))
    }

    @Test fun repeatSummaries() {
        assertEquals("Once", TimeFormat.repeatSummary(emptySet(), us))
        assertEquals("Every day", TimeFormat.repeatSummary(DayOfWeek.values().toSet(), us))
        assertEquals("Weekends", TimeFormat.repeatSummary(setOf(DayOfWeek.SUNDAY, DayOfWeek.SATURDAY), us))
        assertEquals("Mon, Wed", TimeFormat.repeatSummary(setOf(DayOfWeek.WEDNESDAY, DayOfWeek.MONDAY), us))
    }

    @Test fun countdownFormats() {
        assertEquals("0m 5s", TimeFormat.countdown(Duration.ofSeconds(5)))
        assertEquals("2h 3m 4s", TimeFormat.countdown(Duration.ofSeconds(2 * 3600 + 3 * 60 + 4)))
        assertEquals("1d 1h 0m", TimeFormat.countdown(Duration.ofSeconds(86_400 + 3_600)))
        assertEquals("0m 0s", TimeFormat.countdown(Duration.ofSeconds(-30)))
    }

    @Test fun occurrenceLabels() {
        val zone = ZoneId.of("UTC")
        val now = ZonedDateTime.of(2026, 10, 26, 22, 0, 0, 0, zone)
        val tomorrow = ZonedDateTime.of(2026, 10, 27, 7, 0, 0, 0, zone)
        val later = ZonedDateTime.of(2026, 10, 30, 7, 0, 0, 0, zone)
        assertEquals("Tomorrow at 7:00 AM", TimeFormat.describeOccurrence(tomorrow, now, false, us))
        assertEquals("Fri, 30 Oct at 07:00", TimeFormat.describeOccurrence(later, now, true, us))
    }
}
