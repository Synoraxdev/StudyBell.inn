package com.studybell.app

import com.studybell.app.domain.scheduling.NextOccurrence
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.DayOfWeek
import java.time.ZoneId
import java.time.ZonedDateTime

class NextOccurrenceTest {
    private val kolkata = ZoneId.of("Asia/Kolkata")
    private val newYork = ZoneId.of("America/New_York")

    // 2026-10-26 is a Monday.
    private fun mon(h: Int, m: Int, s: Int = 0) = ZonedDateTime.of(2026, 10, 26, h, m, s, 0, kolkata)

    @Test fun oneTimeLaterToday() {
        val next = NextOccurrence.compute(7, 0, emptySet(), mon(6, 0))
        assertEquals(mon(7, 0), next)
    }

    @Test fun oneTimeAlreadyPassedGoesToTomorrow() {
        val next = NextOccurrence.compute(7, 0, emptySet(), mon(8, 0))
        assertEquals(mon(7, 0).plusDays(1), next)
    }

    @Test fun exactlyNowIsNotNext() {
        val next = NextOccurrence.compute(7, 0, emptySet(), mon(7, 0))
        assertEquals(mon(7, 0).plusDays(1), next)
    }

    @Test fun weeklySameDayAfterTimePassedGoesNextWeek() {
        val next = NextOccurrence.compute(7, 0, setOf(DayOfWeek.MONDAY), mon(8, 0))
        assertEquals(mon(7, 0).plusDays(7), next)
    }

    @Test fun weeklySameDayBeforeTimeIsToday() {
        val next = NextOccurrence.compute(7, 0, setOf(DayOfWeek.MONDAY), mon(6, 0))
        assertEquals(mon(7, 0), next)
    }

    @Test fun picksNearestSelectedWeekday() {
        val next = NextOccurrence.compute(7, 0, setOf(DayOfWeek.WEDNESDAY, DayOfWeek.SATURDAY), mon(10, 0))
        assertEquals(DayOfWeek.WEDNESDAY, next.dayOfWeek)
        assertEquals(mon(7, 0).plusDays(2), next)
    }

    @Test fun weekdaysSkipWeekend() {
        val weekdays = setOf(
            DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY,
        )
        val friEvening = ZonedDateTime.of(2026, 10, 30, 20, 0, 0, 0, kolkata)
        val next = NextOccurrence.compute(7, 0, weekdays, friEvening)
        assertEquals(DayOfWeek.MONDAY, next.dayOfWeek)
        assertEquals(3L, java.time.temporal.ChronoUnit.DAYS.between(friEvening.toLocalDate(), next.toLocalDate()))
    }

    @Test fun springForwardGapMovesAlarmForward() {
        val now = ZonedDateTime.of(2027, 3, 13, 12, 0, 0, 0, newYork)
        val next = NextOccurrence.compute(2, 30, emptySet(), now) // 02:30 does not exist on 2027-03-14
        assertEquals(3, next.hour)
        assertEquals(30, next.minute)
    }

    @Test fun fallBackOverlapUsesEarlierInstant() {
        val now = ZonedDateTime.of(2026, 10, 31, 12, 0, 0, 0, newYork)
        val next = NextOccurrence.compute(1, 30, emptySet(), now) // 01:30 happens twice on 2026-11-01
        assertEquals(-4 * 3600, next.offset.totalSeconds)
    }
}
