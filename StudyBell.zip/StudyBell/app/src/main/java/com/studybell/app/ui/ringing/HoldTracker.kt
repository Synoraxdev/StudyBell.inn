package com.studybell.app.ui.ringing

/**
 * Pure hold-to-dismiss state machine, driven by a monotonic [clock] (SystemClock.elapsedRealtime).
 * - Progress is real elapsed time / configured duration.
 * - [release] (finger up, moved outside, cancelled gesture) resets progress to zero.
 * - [tryComplete] returns true at most once, so dismissal can never be triggered twice.
 */
class HoldTracker(private val durationMillis: Long, private val clock: () -> Long) {
    private var pressStart = NOT_PRESSED
    private var finished = false

    val isFinished: Boolean get() = finished
    val isPressed: Boolean get() = pressStart != NOT_PRESSED

    fun press() {
        if (!finished && pressStart == NOT_PRESSED) pressStart = clock()
    }

    fun release() {
        pressStart = NOT_PRESSED
    }

    fun progress(): Float = when {
        finished -> 1f
        pressStart == NOT_PRESSED -> 0f
        else -> ((clock() - pressStart).toFloat() / durationMillis).coerceIn(0f, 1f)
    }

    /** True exactly once, when an uninterrupted hold has lasted the full duration. */
    fun tryComplete(): Boolean {
        if (finished || pressStart == NOT_PRESSED) return false
        if (clock() - pressStart >= durationMillis) {
            finished = true
            return true
        }
        return false
    }

    /** Accessibility path (TalkBack "activate"): completes once without the hold. */
    fun completeForAccessibility(): Boolean {
        if (finished) return false
        finished = true
        return true
    }

    private companion object {
        const val NOT_PRESSED = Long.MIN_VALUE
    }
}
