package com.studybell.app.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.studybell.app.BuildConfig
import com.studybell.app.R
import com.studybell.app.container
import com.studybell.app.core.theme.StudyColors
import com.studybell.app.core.theme.studySwitchColors
import com.studybell.app.domain.model.HOLD_OPTIONS
import com.studybell.app.ui.components.PillSelector
import com.studybell.app.ui.components.RingtoneChooser
import com.studybell.app.ui.components.SecondaryButton
import com.studybell.app.ui.components.SectionLabel
import com.studybell.app.ui.components.SetupChecklist
import com.studybell.app.ui.components.StudyCard
import com.studybell.app.ui.components.StudyTopBar
import com.studybell.app.ui.components.rememberReadiness
import com.studybell.app.ui.components.ringtoneLabel

@Composable
fun SettingsScreen(onBack: () -> Unit, onOpenSetup: () -> Unit) {
    val container = LocalContext.current.container
    val vm: SettingsViewModel = viewModel(
        factory = viewModelFactory { initializer { SettingsViewModel(container.settingsStore) } },
    )
    val s by vm.state.collectAsState()
    val readiness = rememberReadiness()
    var showChooser by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = StudyColors.Background,
        topBar = { StudyTopBar("Settings", onBack = onBack) },
    ) { padding ->
        Column(
            Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            SectionLabel("Defaults for new alarms")
            StudyCard(Modifier.fillMaxWidth()) {
                Text("Default ringtone", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    ringtoneLabel(s.defaultRingtoneUri, s.defaultRingtoneName, null).removePrefix("Default · "),
                    color = StudyColors.TextSecondary,
                )
                Spacer(Modifier.height(10.dp))
                SecondaryButton("Change ringtone", { showChooser = true }, Modifier.fillMaxWidth())
            }
            StudyCard(Modifier.fillMaxWidth()) {
                Text("Default hold duration", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                PillSelector(
                    HOLD_OPTIONS.map { "$it s" },
                    HOLD_OPTIONS.indexOf(s.defaultHoldSeconds).coerceAtLeast(0),
                    { vm.setHold(HOLD_OPTIONS[it]) },
                )
            }
            SwitchCard("Default vibration", "New alarms vibrate while ringing", s.defaultVibrate) { vm.setVibrate(it) }

            SectionLabel("Clock")
            SwitchCard("24-hour clock", "Off shows 12-hour time with AM/PM", s.use24Hour) { vm.setUse24Hour(it) }

            SectionLabel("Alarm readiness")
            SetupChecklist(readiness)
            SecondaryButton("Revisit setup guide", onOpenSetup, Modifier.fillMaxWidth())

            SectionLabel("Battery restrictions")
            StudyCard(Modifier.fillMaxWidth()) {
                Text(
                    "Alarms use Android's alarm-clock scheduler, which is exempt from normal battery limits. " +
                        "Some manufacturers still stop apps aggressively. If an alarm is late or missing: set StudyBell's battery " +
                        "usage to Unrestricted, enable Autostart if your phone has it, and don't force-stop the app. " +
                        "Do Not Disturb normally allows alarms, but check that \"Alarms\" is allowed in your DND settings. " +
                        "StudyBell cannot ring when the phone is off or the alarm volume is muted.",
                    color = StudyColors.TextSecondary, style = MaterialTheme.typography.bodyMedium,
                )
            }

            SectionLabel("About")
            StudyCard(Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.app_name), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("Version ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})", color = StudyColors.TextSecondary)
                Text("Developer: ${stringResource(R.string.developer_name)}", color = StudyColors.TextSecondary)
                Text("Works offline. No account, ads, analytics or tracking.", color = StudyColors.TextSecondary)
            }
            Spacer(Modifier.height(16.dp))
        }
    }

    if (showChooser) {
        RingtoneChooser(
            currentUri = s.defaultRingtoneUri,
            defaultOptionLabel = null,
            onDismiss = { showChooser = false },
            onChosen = { uri, name -> vm.setRingtone(uri, name); showChooser = false },
        )
    }
}

@Composable
private fun SwitchCard(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    StudyCard(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = StudyColors.TextSecondary, style = MaterialTheme.typography.bodySmall)
            }
            Switch(checked = checked, onCheckedChange = onChange, colors = studySwitchColors())
        }
    }
}
