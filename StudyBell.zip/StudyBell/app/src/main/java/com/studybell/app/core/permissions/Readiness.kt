package com.studybell.app.core.permissions

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import com.studybell.app.core.audio.AlarmAudio

/** Real, re-checkable status of everything that affects whether an alarm will be noticed. */
data class Readiness(
    val notificationsAllowed: Boolean,
    /** True on Android < 14 (granted at install) or when the user allowed it on 14+. */
    val fullScreenAllowed: Boolean,
    val fullScreenNeedsUserAction: Boolean,
    val batteryUnrestricted: Boolean,
    val alarmVolumeMuted: Boolean,
) {
    companion object {
        fun check(context: Context): Readiness {
            val nm = context.getSystemService(NotificationManager::class.java)
            val fullScreen = if (Build.VERSION.SDK_INT >= 34) nm.canUseFullScreenIntent() else true
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            return Readiness(
                notificationsAllowed = NotificationManagerCompat.from(context).areNotificationsEnabled(),
                fullScreenAllowed = fullScreen,
                fullScreenNeedsUserAction = Build.VERSION.SDK_INT >= 34,
                batteryUnrestricted = pm.isIgnoringBatteryOptimizations(context.packageName),
                alarmVolumeMuted = AlarmAudio.isAlarmVolumeMuted(context),
            )
        }

        fun appNotificationSettings(context: Context): Intent =
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)

        fun fullScreenSettings(context: Context): Intent =
            if (Build.VERSION.SDK_INT >= 34) {
                Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:${context.packageName}"))
            } else appDetails(context)

        /** System dialog that exempts the app from battery optimisation (falls back to the list screen). */
        @Suppress("BatteryLife")
        fun batterySettings(context: Context): Intent =
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${context.packageName}"))

        /** Manufacturer "autostart / background launch" screens (best effort, first one that exists wins). */
        private fun autostartIntents(): List<Intent> {
            fun c(pkg: String, cls: String) = Intent().setClassName(pkg, cls)
            val m = Build.MANUFACTURER.lowercase()
            fun has(vararg names: String) = names.any { m.contains(it) }
            return when {
                has("xiaomi", "redmi", "poco") -> listOf(
                    c("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"),
                )
                has("oppo", "realme", "oneplus") -> listOf(
                    c("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"),
                    c("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity"),
                    c("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"),
                    c("com.oplus.battery", "com.oplus.powermanager.fuelgaue.PowerUsageModelActivity"),
                )
                has("vivo", "iqoo") -> listOf(
                    c("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"),
                    c("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"),
                )
                has("huawei", "honor") -> listOf(
                    c("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
                    c("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"),
                )
                has("samsung") -> listOf(
                    c("com.samsung.android.lool", "com.samsung.android.sm.battery.ui.BatteryActivity"),
                )
                has("asus") -> listOf(c("com.asus.mobilemanager", "com.asus.mobilemanager.autostart.AutoStartActivity"))
                else -> emptyList()
            }
        }

        /** Opens the phone maker's autostart/background screen, or the app's system page if none exists. */
        fun openAutostart(context: Context) {
            val launched = autostartIntents().any { intent ->
                runCatching { context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess
            }
            if (!launched) open(context, appDetails(context))
        }

        fun soundSettings(): Intent = Intent(Settings.ACTION_SOUND_SETTINGS)

        fun appDetails(context: Context): Intent =
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))

        /** Opens [intent]; falls back to the app's system details page if no handler exists. */
        fun open(context: Context, intent: Intent) {
            runCatching { context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                .onFailure { runCatching { context.startActivity(appDetails(context).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
        }
    }
}
