package com.studybell.app.ui.ringing

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import androidx.compose.foundation.layout.Box
import com.studybell.app.alarm.service.AlarmRuntime
import com.studybell.app.alarm.service.AlarmService
import com.studybell.app.container
import com.studybell.app.core.theme.StudyBellTheme
import com.studybell.app.core.theme.StudyColors
import com.studybell.app.core.time.TimeFormat
import com.studybell.app.domain.model.AppSettings
import com.studybell.app.ui.components.rememberNow
import kotlinx.coroutines.delay

class RingingActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON,
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        setContent {
            StudyBellTheme {
                RingingScreen(onFinished = { finish() })
            }
        }
    }
    // Back simply leaves this screen. The alarm keeps ringing and is NOT dismissed;
    // tap the ongoing notification (or the banner on the home screen) to return.
}

@Composable
fun RingingScreen(onFinished: () -> Unit) {
    val context = LocalContext.current
    val state by AlarmRuntime.state.collectAsState()
    val settings by context.container.settingsStore.settings.collectAsState(initial = AppSettings())
    val now by rememberNow()

    // Close once the service reports nothing is ringing any more; give up if nothing ever starts.
    var seenAlarm by remember { mutableStateOf(false) }
    LaunchedEffect(state) {
        if (state != null) seenAlarm = true else if (seenAlarm) onFinished()
    }
    LaunchedEffect(Unit) {
        delay(4000)
        if (AlarmRuntime.state.value == null) onFinished()
    }

    val current = state
    val holdSeconds = current?.holdSeconds ?: 3
    val label = current?.label?.ifBlank { null } ?: "Alarm"

    Box(Modifier.fillMaxSize().background(StudyColors.Background)) {
        BoxWithConstraints(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 24.dp, vertical = 16.dp)) {
            val buttonSize = min(min(maxWidth * 0.62f, maxHeight * 0.34f), 260.dp)
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                RingingPill()
                Spacer(Modifier.size(16.dp))
                Text(
                    TimeFormat.clockWithSeconds(now, settings.use24Hour),
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                )
                Text(
                    label,
                    style = MaterialTheme.typography.titleLarge,
                    color = StudyColors.TextSecondary,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                )
                if ((current?.queued ?: 0) > 0) {
                    Text(
                        "${current!!.queued} more alarm(s) waiting",
                        style = MaterialTheme.typography.bodyMedium,
                        color = StudyColors.TextSecondary,
                    )
                }
                Spacer(Modifier.weight(1f))
                Text(
                    "Hold for $holdSeconds ${if (holdSeconds == 1) "second" else "seconds"} to stop",
                    style = MaterialTheme.typography.titleMedium,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.size(20.dp))
                if (current != null) {
                    // key() gives each alarm a fresh gesture/progress state (e.g. a queued alarm starting next).
                    androidx.compose.runtime.key(current.alarmId, holdSeconds) {
                        HoldToDismissButton(
                            durationMillis = holdSeconds * 1000L,
                            size = buttonSize,
                            onComplete = { context.startService(AlarmService.dismissIntent(context, current.alarmId)) },
                        )
                    }
                } else {
                    Spacer(Modifier.size(buttonSize))
                }
                Spacer(Modifier.size(20.dp))
                Text(
                    "Leaving this screen does not stop the alarm. Reopen it from the notification.",
                    style = MaterialTheme.typography.bodySmall,
                    color = StudyColors.TextSecondary,
                    textAlign = TextAlign.Center,
                )
            }
        }
    }
}

@Composable
private fun RingingPill() {
    val t = rememberInfiniteTransition(label = "pulse")
    val a by t.animateFloat(0.3f, 1f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "dot")
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.size(10.dp).alpha(a).background(StudyColors.TextPrimary, CircleShape))
        Text("RINGING", style = MaterialTheme.typography.labelLarge, color = StudyColors.TextSecondary)
    }
}
