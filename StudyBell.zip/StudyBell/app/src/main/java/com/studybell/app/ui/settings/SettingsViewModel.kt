package com.studybell.app.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.studybell.app.data.preferences.SettingsStore
import com.studybell.app.domain.model.AppSettings
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(private val store: SettingsStore) : ViewModel() {
    val state: StateFlow<AppSettings> =
        store.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppSettings())

    fun setRingtone(uri: String?, name: String?) = viewModelScope.launch { store.setDefaultRingtone(uri, name) }
    fun setHold(seconds: Int) = viewModelScope.launch { store.setDefaultHoldSeconds(seconds) }
    fun setVibrate(value: Boolean) = viewModelScope.launch { store.setDefaultVibrate(value) }
    fun setUse24Hour(value: Boolean) = viewModelScope.launch { store.setUse24Hour(value) }
}
