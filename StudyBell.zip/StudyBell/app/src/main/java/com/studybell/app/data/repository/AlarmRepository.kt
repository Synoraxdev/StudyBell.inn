package com.studybell.app.data.repository

import com.studybell.app.data.local.AlarmDao
import com.studybell.app.data.local.toDomain
import com.studybell.app.data.local.toEntity
import com.studybell.app.domain.model.Alarm
import com.studybell.app.domain.scheduling.AlarmScheduler
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.ZonedDateTime

const val TEST_LABEL = "Test alarm (10 s)"

/** Single owner of "database + AlarmManager" consistency. */
class AlarmRepository(
    private val dao: AlarmDao,
    private val scheduler: AlarmScheduler,
) {
    val alarms: Flow<List<Alarm>> = dao.observeAll().map { list -> list.map { it.toDomain() } }

    /** Creates a throw-away one-time alarm that rings after [delaySeconds]; it deletes itself when it fires. */
    suspend fun scheduleTest(delaySeconds: Long = 10) {
        val at = ZonedDateTime.now().plusSeconds(delaySeconds)
        val id = dao.upsert(
            Alarm(hour = at.hour, minute = at.minute, label = TEST_LABEL, holdSeconds = 1).toEntity(),
        )
        scheduler.scheduleAt(id, at.toInstant().toEpochMilli())
    }

    suspend fun get(id: Long): Alarm? = dao.get(id)?.toDomain()

    suspend fun save(alarm: Alarm): Long {
        val id = dao.upsert(alarm.toEntity())
        val saved = alarm.copy(id = id)
        if (saved.enabled) scheduler.schedule(saved) else scheduler.cancel(id)
        return id
    }

    suspend fun setEnabled(id: Long, enabled: Boolean) {
        val alarm = get(id) ?: return
        dao.setEnabled(id, enabled)
        if (enabled) scheduler.schedule(alarm.copy(enabled = true)) else scheduler.cancel(id)
    }

    suspend fun delete(id: Long) {
        scheduler.cancel(id)
        dao.delete(id)
    }

    /** Ringtone URIs referenced by saved alarms (used to clean up unused imported tones). */
    suspend fun ringtoneUris(): Set<String> = dao.getAll().mapNotNull { it.ringtoneUri }.toSet()

    /** After boot, app update, or time/timezone change. */
    suspend fun rescheduleAll() {
        dao.getAll().map { it.toDomain() }.forEach {
            if (it.label == TEST_LABEL) { dao.delete(it.id); scheduler.cancel(it.id); return@forEach }
            if (it.enabled) scheduler.schedule(it) else scheduler.cancel(it.id)
        }
    }

    /**
     * Called when an alarm fires. Returns the alarm if it should ring, otherwise null
     * (deleted, disabled, or already consumed = duplicate delivery of a one-time alarm).
     * Repeating alarms get their next occurrence registered immediately, so the chain
     * survives even if the ringing process dies. One-time alarms are switched off.
     */
    suspend fun consumeFire(id: Long): Alarm? {
        val alarm = get(id) ?: return null
        if (!alarm.enabled) return null
        if (alarm.repeatDays.isEmpty()) {
            if (alarm.label == TEST_LABEL) dao.delete(id) else dao.setEnabled(id, false)
            scheduler.cancel(id)
        } else {
            // +30 s: alarms have minute resolution, so a delivery that lands a few ms early can
            // never re-register the same minute (which would ring twice).
            scheduler.schedule(alarm, ZonedDateTime.now().plusSeconds(30))
        }
        return alarm
    }
}
