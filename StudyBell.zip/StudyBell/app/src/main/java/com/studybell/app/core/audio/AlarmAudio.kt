package com.studybell.app.core.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.PowerManager
import android.provider.OpenableColumns
import java.io.File
import java.io.IOException

object AlarmAudio {
    private const val TONE_DIR = "ringtones"
    private const val MAX_IMPORT_BYTES = 30L * 1024 * 1024

    /**
     * Name based resource URI. (The numeric form `android.resource://pkg/<id>` breaks after an
     * app update because resource ids change, which silently made the saved tone unplayable.)
     */
    fun bundledUri(context: Context): Uri =
        Uri.parse("android.resource://${context.packageName}/raw/default_ringtone")

    /** True when the alarm stream volume is 0 (the alarm would be silent). */
    fun isAlarmVolumeMuted(context: Context): Boolean {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return am.getStreamVolume(AudioManager.STREAM_ALARM) == 0
    }

    /** Human-readable name for a picked ringtone / audio file. Never throws. */
    fun displayName(context: Context, uri: Uri): String {
        runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) return n
                }
            }
        }
        runCatching {
            val title = RingtoneManager.getRingtone(context, uri)?.getTitle(context)
            if (!title.isNullOrBlank()) return title
        }
        return "Custom audio"
    }

    private fun toneDir(context: Context) = File(context.filesDir, TONE_DIR)

    /**
     * Copies a picked sound into the app's private storage and returns a file:// Uri for it.
     * A private copy keeps playing even if the original file is moved/deleted, the picker's
     * temporary permission expires, or (Android 13+) the audio permission is not granted.
     * Returns null when the source cannot be read (caller may then keep the original Uri).
     * Blocking: call from a background thread.
     */
    fun importToPrivate(context: Context, source: Uri, originalName: String?): Uri? {
        val dir = toneDir(context)
        if (!dir.exists() && !dir.mkdirs()) return null
        val ext = originalName?.substringAfterLast('.', "")?.lowercase()
            ?.takeIf { it.length in 1..5 && it.all { ch -> ch.isLetterOrDigit() } } ?: "audio"
        val out = File(dir, "tone_${System.currentTimeMillis()}.$ext")
        return try {
            var total = 0L
            val input = context.contentResolver.openInputStream(source) ?: return null
            input.use { ins ->
                out.outputStream().use { outs ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        total += n
                        if (total > MAX_IMPORT_BYTES) throw IOException("Audio file too large")
                        outs.write(buf, 0, n)
                    }
                }
            }
            if (total == 0L) { out.delete(); null } else Uri.fromFile(out)
        } catch (e: Exception) {
            runCatching { out.delete() }
            null
        }
    }

    /** Deletes imported tones that no alarm/setting references any more (older than 1 h only). */
    fun pruneUnused(context: Context, inUse: Set<String>) {
        val files = toneDir(context).listFiles() ?: return
        val keep = inUse.mapNotNull { runCatching { Uri.parse(it).path }.getOrNull() }.toSet()
        val cutoff = System.currentTimeMillis() - 60 * 60 * 1000L
        files.forEach { f -> if (f.absolutePath !in keep && f.lastModified() < cutoff) runCatching { f.delete() } }
    }
}

/**
 * Plays one alarm sound at a time using USAGE_ALARM (follows the alarm volume stream; the app never
 * changes system volume). If the chosen sound cannot be opened or fails mid-playback, it falls back
 * to the bundled ringtone.
 */
class AlarmPlayer(private val context: Context) {
    private var player: MediaPlayer? = null
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var focusRequest: AudioFocusRequest? = null

    private val attributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ALARM)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    fun start(uriString: String?, loop: Boolean = true, onFinished: (() -> Unit)? = null) {
        stop()
        requestFocus()
        val custom = uriString?.let { runCatching { Uri.parse(it) }.getOrNull() }
        val ok = custom != null && play(custom, loop, onFinished, isFallback = false)
        if (!ok) play(AlarmAudio.bundledUri(context), loop, onFinished, isFallback = true)
    }

    private fun play(uri: Uri, loop: Boolean, onFinished: (() -> Unit)?, isFallback: Boolean): Boolean {
        val mp = MediaPlayer()
        return try {
            mp.setAudioAttributes(attributes)
            mp.setWakeMode(context, PowerManager.PARTIAL_WAKE_LOCK)
            mp.setDataSource(context, uri)
            mp.isLooping = loop
            mp.setOnPreparedListener { if (player === it) it.start() }
            mp.setOnCompletionListener {
                if (!loop && player === it) {
                    // One-shot (preview) finished: free the player and give audio focus back.
                    stop()
                    onFinished?.invoke()
                }
            }
            mp.setOnErrorListener { _, _, _ ->
                if (player === mp) {
                    release()
                    if (!isFallback) {
                        play(AlarmAudio.bundledUri(context), loop, onFinished, true)
                    } else {
                        abandonFocus()
                        onFinished?.invoke()
                    }
                }
                true
            }
            player = mp
            mp.prepareAsync()
            true
        } catch (e: Exception) {
            runCatching { mp.release() }
            if (player === mp) player = null
            false
        }
    }

    fun stop() {
        release()
        abandonFocus()
    }

    private fun release() {
        player?.let { mp ->
            player = null
            runCatching { mp.setOnCompletionListener(null) }
            runCatching { mp.setOnErrorListener(null) }
            runCatching { if (mp.isPlaying) mp.stop() }
            runCatching { mp.release() }
        }
    }

    private fun requestFocus() {
        if (focusRequest != null) return
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attributes)
            .setOnAudioFocusChangeListener { /* Alarm keeps playing: it must not be silenced by other apps. */ }
            .build()
        focusRequest = req
        audioManager.requestAudioFocus(req)
    }

    private fun abandonFocus() {
        focusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
        focusRequest = null
    }
}
