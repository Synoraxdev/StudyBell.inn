package com.studybell.app.ui.ringing

import android.os.SystemClock
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.studybell.app.core.theme.StudyColors
import kotlinx.coroutines.isActive

/**
 * Large fingerprint-style touch target. This is a plain touch gesture (NOT biometric authentication).
 * Only the first finger that lands is tracked; extra fingers are ignored and cannot speed up or
 * bypass the hold. Lifting, sliding off the circle, or a cancelled gesture resets progress to 0.
 *
 * Accessibility exception: a press-and-hold cannot be performed with many assistive technologies,
 * so the node exposes a single semantic "activate" action that stops the alarm directly.
 */
@Composable
fun HoldToDismissButton(
    durationMillis: Long,
    onComplete: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 220.dp,
) {
    val haptics = LocalHapticFeedback.current
    val tracker = remember(durationMillis) { HoldTracker(durationMillis, SystemClock::elapsedRealtime) }
    val currentOnComplete by rememberUpdatedState(onComplete)
    var pressed by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var done by remember { mutableStateOf(false) }

    LaunchedEffect(pressed, tracker) {
        if (!pressed) {
            progress = 0f
            return@LaunchedEffect
        }
        while (isActive) {
            progress = tracker.progress()
            if (tracker.tryComplete()) {
                progress = 1f
                done = true
                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                currentOnComplete()
                break
            }
            androidx.compose.runtime.withFrameNanos { }
        }
    }

    val scale by animateFloatAsState(if (pressed && !done) 0.96f else 1f, label = "press-scale")
    val percent = (progress * 100).toInt()
    val seconds = (durationMillis / 1000L).toInt()

    Box(
        modifier
            .size(size)
            .scale(scale)
            .semantics(mergeDescendants = true) {
                role = Role.Button
                contentDescription = "Stop alarm. Press and hold for $seconds seconds."
                stateDescription = "$percent percent"
                onClick(label = "Stop alarm now") {
                    if (tracker.completeForAccessibility()) {
                        done = true
                        currentOnComplete()
                    }
                    true
                }
            }
            .pointerInput(tracker) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val pointerId = down.id
                    val radius = this.size.width / 2f
                    val center = Offset(this.size.width / 2f, this.size.height / 2f)
                    if ((down.position - center).getDistance() > radius) {
                        // Touched a corner of the square bounds, outside the circle: ignore this gesture.
                        waitForUpOrCancellation()
                        return@awaitEachGesture
                    }
                    tracker.press()
                    pressed = true
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    down.consume()
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == pointerId } ?: break // gesture cancelled
                        if (!change.pressed) break
                        if ((change.position - center).getDistance() > radius) break          // slid off the target
                        change.consume()
                    }
                    tracker.release()
                    pressed = false
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        val ringStroke = 8.dp
        Canvas(Modifier.size(size)) {
            val stroke = ringStroke.toPx()
            val inset = stroke / 2f
            val arcSize = Size(this.size.width - stroke, this.size.height - stroke)
            drawArc(
                color = StudyColors.Border, startAngle = 0f, sweepAngle = 360f, useCenter = false,
                topLeft = Offset(inset, inset), size = arcSize, style = Stroke(stroke),
            )
            if (progress > 0f) {
                drawArc(
                    color = StudyColors.TextPrimary, startAngle = -90f, sweepAngle = 360f * progress, useCenter = false,
                    topLeft = Offset(inset, inset), size = arcSize, style = Stroke(stroke, cap = StrokeCap.Round),
                )
            }
        }
        Box(
            Modifier
                .size(size - 28.dp)
                .background(if (pressed) StudyColors.Elevated else StudyColors.Surface, CircleShape)
                .border(1.dp, StudyColors.Border, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.size(size * 0.5f)) { drawFingerprint(StudyColors.TextPrimary, 4.dp.toPx()) }
        }
    }
}

private fun DrawScope.drawFingerprint(color: Color, stroke: Float) {
    val c = center
    val r = size.minDimension / 2f
    val rings = listOf(0.16f, 0.32f, 0.48f, 0.64f, 0.80f, 0.96f)
    rings.forEachIndexed { i, f ->
        val rad = r * f
        val start = 195f + i * 14f
        val sweep = 255f - i * 8f
        drawArc(
            color = color, startAngle = start, sweepAngle = sweep, useCenter = false,
            topLeft = Offset(c.x - rad, c.y - rad), size = Size(rad * 2, rad * 2),
            style = Stroke(stroke, cap = StrokeCap.Round),
        )
        // A second, shorter arc on the opposite side gives the ridged fingerprint look.
        if (i % 2 == 1) {
            drawArc(
                color = color, startAngle = start + sweep + 25f, sweepAngle = 40f, useCenter = false,
                topLeft = Offset(c.x - rad, c.y - rad), size = Size(rad * 2, rad * 2),
                style = Stroke(stroke, cap = StrokeCap.Round),
            )
        }
    }
    drawCircle(color, radius = stroke * 0.6f, center = c)
}
