package com.studybell.app.ui.components

import android.app.Activity
import android.content.Intent
import android.widget.Toast
import android.media.RingtoneManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.core.content.IntentCompat
import com.studybell.app.R
import com.studybell.app.core.audio.AlarmAudio
import com.studybell.app.core.theme.StudyColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Ringtone source chooser. Uses the system ringtone picker and the Storage Access Framework
 * document picker, so no storage permission is needed. Every picked sound is copied into the
 * app's private storage; if a sound ever cannot be opened the player falls back to the bundled tone.
 */
@Composable
fun RingtoneChooser(
    currentUri: String?,
    defaultOptionLabel: String?,
    onDismiss: () -> Unit,
    onChosen: (uri: String?, name: String?) -> Unit,
) {
    val context = LocalContext.current
    val bundledName = stringResource(R.string.bundled_tone_name)
    val scope = rememberCoroutineScope()

    /**
     * Copies the picked sound into private app storage (so it keeps working after reboot, file
     * moves, expired grants and without any storage permission) and then reports it.
     */
    fun importAndChoose(uri: Uri, keepOriginalOnFailure: Boolean) {
        scope.launch {
            val name = AlarmAudio.displayName(context, uri)
            val local = withContext(Dispatchers.IO) { AlarmAudio.importToPrivate(context, uri, name) }
            when {
                local != null -> onChosen(local.toString(), name)
                keepOriginalOnFailure -> onChosen(uri.toString(), name)
                else -> {
                    Toast.makeText(context, "Could not use that file (unreadable or larger than 30 MB).", Toast.LENGTH_LONG).show()
                    onDismiss()
                }
            }
        }
    }

    val systemPicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val uri = res.data?.let {
            IntentCompat.getParcelableExtra(it, RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
        }
        if (res.resultCode == Activity.RESULT_OK && uri != null) importAndChoose(uri, keepOriginalOnFailure = true)
        else onDismiss()
    }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) onDismiss() else importAndChoose(uri, keepOriginalOnFailure = false)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StudyColors.Elevated,
        title = { Text("Choose ringtone") },
        text = {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.Start) {
                if (defaultOptionLabel != null) {
                    ChooserOption("Use default ($defaultOptionLabel)") { onChosen(null, null) }
                }
                ChooserOption(bundledName) { onChosen(AlarmAudio.bundledUri(context).toString(), bundledName) }
                ChooserOption("System ringtone…") {
                    val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                        .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                        .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, false)
                        .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                        .putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Choose alarm sound")
                    currentUri?.takeIf { it.startsWith("content://") }?.let {
                        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(it))
                    }
                    systemPicker.launch(intent)
                }
                ChooserOption("Audio file from this device…") { filePicker.launch(arrayOf("audio/*")) }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun ChooserOption(text: String, onClick: () -> Unit) {
    TextButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Text(text, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
    }
}

/** Label shown on cards/rows for an alarm's ringtone. */
@Composable
fun ringtoneLabel(alarmUri: String?, alarmName: String?, defaultName: String?): String {
    val bundled = stringResource(R.string.bundled_tone_name)
    return if (alarmUri != null) alarmName ?: "Custom audio" else "Default · ${defaultName ?: bundled}"
}
