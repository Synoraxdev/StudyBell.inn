# Fix log (review pass)

The original project had never been compiled or run. This pass was a careful source review (no Android SDK was available
to build here), so please run the CI once and test on a phone using `docs/DEVICE_CHECKLIST.md`.

## Style / UI
- **Invisible text:** the ringing screen and the onboarding screens had black text on a near-black background
  (no root Surface = default content colour black). `StudyBellTheme` now wraps everything in a Surface with white content colour.
- **TimePicker:** selected hour/minute and AM/PM were indistinguishable in the monochrome theme; explicit high-contrast colours added.
- Settings screen had double bottom padding (removed).
- Hold button: touching the square's corners (outside the circle) no longer starts a hold.
- Onboarding: the "hold" practice could be done only once; "Practice again" added.

## Ringtone / audio
- Bundled tone was saved as `android.resource://pkg/<numeric id>`; resource ids change on app update, so the saved tone broke.
  Now name based (`.../raw/default_ringtone`).
- Any tone picked from "System ringtone" or "Audio file" is **copied into the app's private storage** and played from there:
  works without storage permission (Android 13+), after reboot, and if the original file is moved/deleted. Max 30 MB.
  Unused copies are cleaned up at app start.
- Preview: a finished preview now releases the player and audio focus.
- Player ignores stale callbacks after stop; fallback to the bundled tone kept.

## Alarm engine
- Foreground-service notification now shows the ringing alarm's label, also when a second alarm fires (it used to reset to "Alarm").
- Refused foreground start (Android 12+ restrictions) can no longer crash the app (receiver + service wrapped).
- Repeating alarm re-registration after firing uses +30 s so an early delivery can't ring the same minute twice.
- Vibrate only if the device has a vibrator.
- Notification permission (Android 13+) is requested on first launch; without it the ringing screen/notification is hidden.

## Build
- Added `material-icons-core` explicitly; added Gradle wrapper (`gradlew`, jar).
- Editor: time can now also be typed with the keyboard (toggle under the clock dial).
- Background reliability: direct "no battery restrictions" system dialog, "Autostart / background launch" shortcut
  (Xiaomi/Oppo/Realme/Vivo/Huawei/Samsung), and Settings -> "Ring in 10 seconds" test alarm.
