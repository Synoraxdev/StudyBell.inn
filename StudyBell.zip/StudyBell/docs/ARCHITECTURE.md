# Architecture

```
app/src/main/java/com/studybell/app
  StudyBellApp.kt           Application + tiny AppContainer (Room, DataStore, scheduler, repository)
  core/audio                AlarmPlayer (one MediaPlayer, USAGE_ALARM, loop, fallback), AlarmAudio helpers
  core/notifications        channel + ongoing alarm notification with full-screen intent
  core/permissions          Readiness: real status of notifications / full-screen / battery / alarm volume
  core/time                 TimeFormat (pure, unit-tested)
  core/theme                monochrome palette + Material 3 theme
  data/local                Room: AlarmEntity, AlarmDao, AppDatabase
  data/preferences          SettingsStore (DataStore)
  data/repository           AlarmRepository: DB + scheduler stay consistent; consumeFire()
  domain/model              Alarm, AppSettings
  domain/scheduling         NextOccurrence (pure), AlarmScheduler (AlarmManager.setAlarmClock)
  alarm/receiver            AlarmReceiver (fire -> service), BootReceiver (reboot/time/timezone -> reschedule)
  alarm/service             AlarmService (foreground, mediaPlayback), AlarmRuntime (StateFlow of ringing state)
  ui/*                      Compose screens + ViewModels (home, editor, settings), onboarding, ringing, navigation
```

**Alarm flow:** `AlarmScheduler.setAlarmClock` → system fires `AlarmReceiver` → `AlarmService.startForeground` →
`repository.consumeFire(id)` (reschedules repeats / disables one-time) → player + vibration + notification (full-screen intent →
`RingingActivity`) → hold completes → `ACTION_DISMISS(id)` → service stops audio/vibration, removes notification, starts next queued alarm or stops.

**State:** Room is the source of truth for alarms; DataStore for settings; `AlarmRuntime.state` (in-memory) for what rings now.
**Hold gesture:** `HoldTracker` (pure, monotonic clock) + `HoldToDismissButton` (first-pointer-only gesture, resets on release/exit/cancel).
