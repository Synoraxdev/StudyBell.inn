# Physical-device verification checklist

Test on at least one Android 13+ phone and, ideally, one Android 8-12 phone and one Xiaomi/Oppo/Samsung phone.

- [ ] Install debug APK, complete onboarding; checklist statuses match the real system settings (toggle a permission off/on and return).
- [ ] Default (bundled) tone plays in the editor preview and stops with Stop.
- [ ] Create alarm 2 minutes ahead; "Next ring" in the editor and Home countdown agree.
- [ ] Screen on, app open: alarm rings; app in background; app swiped from recents; screen off; phone locked (ringing screen over lock screen).
- [ ] Tone loops. Releasing early resets the ring and the sound keeps playing. Sliding the finger off the circle resets. Two fingers don't speed it up.
- [ ] Completing the hold stops sound + vibration, removes the notification, closes the screen. Repeat for 1 s, 2 s, 3 s.
- [ ] Back button on the ringing screen: alarm keeps ringing; notification / Home banner returns to it.
- [ ] One-time alarm turns off after ringing; weekday alarm is scheduled for the next selected day.
- [ ] Reboot, unlock, confirm alarms still fire. Change timezone / clock, confirm next-alarm updates.
- [ ] Two alarms 1 minute apart / same minute: only one sound at a time; the second starts after the first is dismissed.
- [ ] Custom audio file and system ringtone; then delete/move the file and confirm the bundled tone plays.
- [ ] Alarm volume at 0: warning shows in checklist. Do Not Disturb with alarms allowed still rings.
- [ ] TalkBack: ringing button announces "Stop alarm", double-tap stops it.
- [ ] Font size at maximum, small phone, landscape: no clipped controls.
