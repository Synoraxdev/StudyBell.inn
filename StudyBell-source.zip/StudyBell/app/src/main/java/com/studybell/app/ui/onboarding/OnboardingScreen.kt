package com.studybell.app.ui.onboarding

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.studybell.app.core.theme.StudyColors
import com.studybell.app.ui.components.PrimaryButton
import com.studybell.app.ui.components.SecondaryButton
import com.studybell.app.ui.components.SetupChecklist
import com.studybell.app.ui.components.rememberReadiness
import com.studybell.app.ui.ringing.HoldToDismissButton

private const val LAST_PAGE = 3

@Composable
fun OnboardingScreen(onDone: () -> Unit) {
    var page by rememberSaveable { mutableIntStateOf(0) }
    val readiness = rememberReadiness()

    Column(Modifier.fillMaxSize().background(StudyColors.Background).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.End) {
            if (page < LAST_PAGE) TextButton(onClick = { page = LAST_PAGE }) { Text("Skip to setup") }
            else Spacer(Modifier.height(48.dp))
        }
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            when (page) {
                0 -> Page("Wake up. Really.", "StudyBell is an offline alarm made for students. Set your times, pick your own ringtone, and the alarm keeps ringing until you prove you are awake.")
                1 -> {
                    Page("How alarms work", "Each alarm is registered with Android's alarm-clock scheduler, so it can ring when the app is closed, the screen is off, or the phone is locked. Alarms are saved on your phone and restored after a restart.")
                    Text(
                        "Limits: an alarm cannot ring if the phone is powered off, if you force-stop the app, or if the alarm volume is muted. Some manufacturers add extra battery limits.",
                        style = MaterialTheme.typography.bodyMedium, color = StudyColors.TextSecondary,
                    )
                }
                2 -> {
                    Page("Hold to stop", "To dismiss an alarm, press and hold the fingerprint-style button for the time you chose (1–3 seconds). Let go early and progress resets while the sound keeps playing. It is just a touch target; it never uses your real fingerprint.")
                    var practiced by rememberSaveable { mutableStateOf(false) }
                    Box(Modifier.fillMaxWidth().padding(top = 8.dp), contentAlignment = Alignment.Center) {
                        HoldToDismissButton(durationMillis = 2000L, onComplete = { practiced = true }, size = 190.dp)
                    }
                    Text(
                        if (practiced) "Nice. That is exactly how you stop an alarm." else "Try it: hold for 2 seconds (practice only).",
                        Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodyMedium, color = StudyColors.TextSecondary,
                    )
                }
                else -> {
                    Page("Setup checklist", "These are the real current statuses. You can continue without them, but the alarm may be less visible. You can come back from Settings at any time.")
                    SetupChecklist(readiness)
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                repeat(LAST_PAGE + 1) { i ->
                    Box(Modifier.size(8.dp).background(if (i == page) StudyColors.TextPrimary else StudyColors.Border, CircleShape))
                }
            }
            if (page > 0) {
                SecondaryButton("Back", { page -= 1 }, Modifier.padding(end = 8.dp))
            }
            if (page < LAST_PAGE) PrimaryButton("Next", { page += 1 })
            else PrimaryButton("Finish", onDone)
        }
    }
}

@Composable
private fun Page(title: String, body: String) {
    Spacer(Modifier.height(24.dp))
    Text(title, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
    Text(body, style = MaterialTheme.typography.bodyLarge, color = StudyColors.TextSecondary)
}
